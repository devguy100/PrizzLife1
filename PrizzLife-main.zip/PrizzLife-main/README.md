<h1 align="center">PrizzLife Admin</h1>
<h2 align="center">RECONTINUED - OPEN SOURCE</h2>

<p align="center">
  <img src="https://img.shields.io/badge/Status-Active-green" alt="Status">
  <img src="https://img.shields.io/badge/Version-0.9.4-blue" alt="Version">
  <img src="https://img.shields.io/github/license/devguy100/PrizzLife" alt="License">
</p>

<p align="center">
  <strong>PrizzLife</strong> - A powerful exploit tool for Roblox <a href="https://www.roblox.com/games/155615604/Prison-Life">Prison Life</a> with multi-executor support.
</p>

---

## 🚀 Supported Executors

```plaintext
LibHydrogen based executors: Delta X 2.0, Hydrogen, MacSploit
LibArceusX based executors: Arceus X Neo, Codex, VegaX, Evon, Trigon
Misc executors: Fluxus, Solara PC, Swift, Other Mobile Executors, etc.
```

---

### Discord:
<div style="text-align: center;">
  <a href="https://discord.gg/pnh2RyzR6W" target="_blank">Join our Discord</a>
</div>

---

## 🔗 Usage

Copy and paste the following script into your Roblox executor to load PrizzLife:

```lua
loadstring(game:HttpGet('https://raw.githubusercontent.com/devguy100/PrizzLife/main/pladmin.lua'))()
```

---

## Credits

Credits to these people:

- Wrath Admin
- [Infinity Yield](https://raw.githubusercontent.com/edgeiy/infiniteyield/master/source)
- [Styx-Developer](https://github.com/Styx-Developer)
- Tiger Admin
- [H17S3](https://github.com/h17s3)
- elliexmln

---

## 📜 License

This project is licensed under the MIT License. See the LICENSE file for more details.

---

<p align="center">
  <strong>Happy exploiting! 🚀</strong>
</p>
